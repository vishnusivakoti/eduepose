package com.Project.Security.dto;

public class UpdateAminDto {
	String username;
	String Roles;
	String email;
	public String getUsername() {
		return username;
	}
	public void setUsername(String username) {
		this.username = username;
	}
	public String getRoles() {
		return Roles;
	}
	public void setRoles(String roles) {
		Roles = roles;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public UpdateAminDto(String username, String roles, String email) {
		super();
		this.username = username;
		Roles = roles;
		this.email = email;
	}
	public UpdateAminDto() {
		super();
	}
	

}
