package com.Project.TrainService.service;

import com.Project.TrainService.dto.TrainDTO;
import com.Project.TrainService.dto.RouteConnectionDTO;
import com.Project.TrainService.dto.RouteDTO;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.List;

public interface TrainService {
    TrainDTO createTrain(TrainDTO trainDTO);
    TrainDTO getTrainById(Integer trainId);
    List<TrainDTO> getAllTrains();
    TrainDTO updateTrain(Integer trainId, TrainDTO trainDTO);
    void deleteTrain(Integer trainId);
    
    List<TrainDTO> findTrainsByRoute(String source, String destination, LocalDate travelDate);
    List<TrainDTO> findAvailableTrainsByRoute(String source, String destination, LocalDate travelDate);
    
    // Special method for finding routes with connections using BFS
    List<RouteDTO> findRoutesWithConnections(String source, String destination, LocalDate travelDate, int maxStops);
    
    List<TrainDTO> findTrainsBySource(String source);
    List<TrainDTO> findTrainsByDestination(String destination);
    List<TrainDTO> findTrainsByDate(LocalDate travelDate);
    
    boolean updateTicketAvailability(Integer trainId, int ticketsToBook);
    List<TrainDTO> findAvailableTrainsByRouteAndTime(String source, String destination, 
            LocalDate travelDate, LocalDateTime startTime, 
            LocalDateTime endTime);
    boolean bookTicketsAndUpdateAvailability(Integer trainId, int ticketsToBook);
    List<RouteConnectionDTO> findAvailableRoutesWithConnections(String source, String destination,
                        LocalDate travelDate, int maxStops);
}
