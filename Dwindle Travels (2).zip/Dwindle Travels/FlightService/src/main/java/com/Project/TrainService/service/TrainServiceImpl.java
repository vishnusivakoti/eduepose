package com.Project.TrainService.service;


import com.Project.TrainService.Exception.TrainNotFoundException;
import com.Project.TrainService.Exception.TrainValidationException;
import com.Project.TrainService.dto.RouteConnectionDTO;
import com.Project.TrainService.dto.RouteDTO;
import com.Project.TrainService.dto.TrainDTO;
import com.Project.TrainService.entity.Train;
import com.Project.TrainService.repository.TrainRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.*;
import java.util.stream.Collectors;

@Service
@Transactional
public class TrainServiceImpl implements TrainService {

    @Autowired
    private TrainRepository trainRepository;

    @Override
    public TrainDTO createTrain(TrainDTO trainDTO) {
        validateTrainDTO(trainDTO);
        validateTrainTiming(trainDTO);
        validateUniqueTrainName(trainDTO.getTrainName());
        
        Train train = convertToEntity(trainDTO);
        Train savedTrain = trainRepository.save(train);
        return convertToDTO(savedTrain);
    }

    @Override
    public TrainDTO getTrainById(Integer trainId) {
        Train train = trainRepository.findById(trainId)
                .orElseThrow(() -> new TrainNotFoundException("Train not found with ID: " + trainId));
        return convertToDTO(train);
    }

    @Override
    public List<TrainDTO> getAllTrains() {
        List<Train> trains = trainRepository.findAll();
        return trains.stream()
                .map(this::convertToDTO)
                .collect(Collectors.toList());
    }

    @Override
    public TrainDTO updateTrain(Integer trainId, TrainDTO trainDTO) {
        Train existingTrain = trainRepository.findById(trainId)
                .orElseThrow(() -> new TrainNotFoundException("Train not found with ID: " + trainId));
        
        validateTrainDTO(trainDTO);
        validateTrainTiming(trainDTO);
        
        // Check if train name is being updated to a name that already exists
        if (!existingTrain.getTrainName().equals(trainDTO.getTrainName())) {
            validateUniqueTrainName(trainDTO.getTrainName());
        }
        
        updateTrainEntity(existingTrain, trainDTO);
        Train updatedTrain = trainRepository.save(existingTrain);
        return convertToDTO(updatedTrain);
    }

    @Override
    public void deleteTrain(Integer trainId) {
        if (!trainRepository.existsById(trainId)) {
            throw new TrainNotFoundException("Train not found with ID: " + trainId);
        }
        trainRepository.deleteById(trainId);
    }

    @Override
    public List<TrainDTO> findTrainsByRoute(String source, String destination, LocalDate travelDate) {
        List<Train> trains = trainRepository.findBySourceAndDestinationAndTravelDate(source, destination, travelDate);
        return trains.stream()
                .map(this::convertToDTO)
                .collect(Collectors.toList());
    }

    @Override
    public List<TrainDTO> findAvailableTrainsByRoute(String source, String destination, LocalDate travelDate) {
        List<Train> trains = trainRepository.findBySourceAndDestinationAndTravelDateAndTicketAvailabilityGreaterThan(
                source, destination, travelDate, 0);
        return trains.stream()
                .map(this::convertToDTO)
                .collect(Collectors.toList());
    }

    @Override
    public List<RouteDTO> findRoutesWithConnections(String source, String destination, LocalDate travelDate, int maxStops) {
        List<RouteDTO> routes = new ArrayList<>();
        
        // First, try to find direct routes
        List<TrainDTO> directTrains = findAvailableTrainsByRoute(source, destination, travelDate);
        for (TrainDTO train : directTrains) {
            RouteDTO route = new RouteDTO();
            route.setTrains(Arrays.asList(train));
            route.setTotalPrice(train.getPrices());
            route.setTotalTravelHours(train.getTravelHours());
            route.setRouteDescription(source + " -> " + destination + " (Direct)");
            route.setTotalStops(0);
            routes.add(route);
        }
        
        // If no direct routes found, use BFS to find connecting routes
        if (routes.isEmpty() && maxStops > 0) {
            routes.addAll(findConnectingRoutes(source, destination, travelDate, maxStops));
        }
        
        // Sort routes by total travel hours
        routes.sort(Comparator.comparingDouble(RouteDTO::getTotalTravelHours));
        
        return routes;
    }

    private List<RouteDTO> findConnectingRoutes(String source, String destination, LocalDate travelDate, int maxStops) {
        List<RouteDTO> connectingRoutes = new ArrayList<>();
        
        // BFS implementation for finding routes
        Queue<RouteState> queue = new LinkedList<>();
        Set<String> visitedCities = new HashSet<>();
        
        // Initialize with trains from source
        List<Train> initialTrains = trainRepository.findAvailableTrainsFromSource(source, travelDate);
        for (Train train : initialTrains) {
            RouteState initialState = new RouteState();
            initialState.currentCity = train.getDestination();
            initialState.route = new ArrayList<>();
            initialState.route.add(convertToDTO(train));
            initialState.totalPrice = train.getPrices();
            initialState.totalHours = train.getTravelHours();
            initialState.stops = 1;
            initialState.lastArrivalTime = train.getArrivalTime();
            
            if (train.getDestination().equals(destination)) {
                // Found a direct connection
                RouteDTO route = createRouteDTO(initialState, source + " -> " + destination);
                connectingRoutes.add(route);
            } else if (initialState.stops < maxStops) {
                queue.offer(initialState);
            }
        }
        
        while (!queue.isEmpty() && connectingRoutes.size() < 10) { // Limit results
            RouteState current = queue.poll();
            
            if (visitedCities.contains(current.currentCity) || current.stops >= maxStops) {
                continue;
            }
            
            visitedCities.add(current.currentCity);
            
            // Find next connecting trains from current city
            LocalDate nextTravelDate = current.lastArrivalTime.toLocalDate();
            if (current.lastArrivalTime.getHour() >= 18) { // If arrival is late, travel next day
                nextTravelDate = nextTravelDate.plusDays(1);
            }
            
            List<Train> nextTrains = trainRepository.findAvailableTrainsFromSource(current.currentCity, nextTravelDate);
            
            for (Train train : nextTrains) {
                if (train.getDepartureTime().isAfter(current.lastArrivalTime.plusHours(2))) { // 2-hour layover
                    RouteState newState = new RouteState();
                    newState.currentCity = train.getDestination();
                    newState.route = new ArrayList<>(current.route);
                    newState.route.add(convertToDTO(train));
                    newState.totalPrice = current.totalPrice + train.getPrices();
                    newState.totalHours = current.totalHours + train.getTravelHours();
                    newState.stops = current.stops + 1;
                    newState.lastArrivalTime = train.getArrivalTime();
                    
                    if (train.getDestination().equals(destination)) {
                        // Found route to destination
                        String routeDesc = buildRouteDescription(newState.route);
                        RouteDTO route = createRouteDTO(newState, routeDesc);
                        connectingRoutes.add(route);
                    } else if (newState.stops < maxStops) {
                        queue.offer(newState);
                    }
                }
            }
        }
        
        return connectingRoutes;
    }

    private RouteDTO createRouteDTO(RouteState state, String description) {
        RouteDTO route = new RouteDTO();
        route.setTrains(state.route);
        route.setTotalPrice(state.totalPrice);
        route.setTotalTravelHours(state.totalHours);
        route.setRouteDescription(description);
        route.setTotalStops(state.stops - 1);
        return route;
    }

    private String buildRouteDescription(List<TrainDTO> trains) {
        StringBuilder desc = new StringBuilder();
        for (int i = 0; i < trains.size(); i++) {
            TrainDTO train = trains.get(i);
            if (i == 0) {
                desc.append(train.getSource());
            }
            desc.append(" -> ").append(train.getDestination());
        }
        return desc.toString();
    }

    // Inner class for BFS state
    private static class RouteState {
        String currentCity;
        List<TrainDTO> route;
        int totalPrice;
        double totalHours;
        int stops;
        LocalDateTime lastArrivalTime;
    }

    @Override
    public List<TrainDTO> findTrainsBySource(String source) {
        List<Train> trains = trainRepository.findBySource(source);
        return trains.stream()
                .map(this::convertToDTO)
                .collect(Collectors.toList());
    }

    @Override
    public List<TrainDTO> findTrainsByDestination(String destination) {
        List<Train> trains = trainRepository.findByDestination(destination);
        return trains.stream()
                .map(this::convertToDTO)
                .collect(Collectors.toList());
    }

    @Override
    public List<TrainDTO> findTrainsByDate(LocalDate travelDate) {
        List<Train> trains = trainRepository.findByTravelDate(travelDate);
        return trains.stream()
                .map(this::convertToDTO)
                .collect(Collectors.toList());
    }

    @Override
    public boolean updateTicketAvailability(Integer trainId, int ticketsToBook) {
        Train train = trainRepository.findById(trainId)
                .orElseThrow(() -> new TrainNotFoundException("Train not found with ID: " + trainId));
        
        if (train.getTicketAvailability() >= ticketsToBook) {
            train.setTicketAvailability(train.getTicketAvailability() - ticketsToBook);
            trainRepository.save(train);
            return true;
        }
        return false;
    }

    // Validation methods
    private void validateTrainDTO(TrainDTO trainDTO) {
        if (trainDTO.getSource().equalsIgnoreCase(trainDTO.getDestination())) {
            throw new TrainValidationException("Source and destination cannot be the same");
        }
        
        if (trainDTO.getTravelDate().isBefore(LocalDate.now())) {
            throw new TrainValidationException("Travel date cannot be in the past");
        }
    }

    private void validateTrainTiming(TrainDTO trainDTO) {
        if (trainDTO.getArrivalTime().isBefore(trainDTO.getDepartureTime())) {
            throw new TrainValidationException("Arrival time cannot be before departure time");
        }
        
        // Calculate expected arrival time based on departure time and travel hours
        LocalDateTime expectedArrival = trainDTO.getDepartureTime().plusHours((long) trainDTO.getTravelHours())
                .plusMinutes((long) ((trainDTO.getTravelHours() % 1) * 60));
        
        if (Math.abs(trainDTO.getArrivalTime().compareTo(expectedArrival)) > 3600) { // 1 hour tolerance
            throw new TrainValidationException("Arrival time does not match with departure time and travel hours");
        }
    }

    private void validateUniqueTrainName(String trainName) {
        if (trainRepository.existsByTrainName(trainName)) {
            throw new TrainValidationException("Train with name '" + trainName + "' already exists");
        }
    }

    // Conversion methods
    private Train convertToEntity(TrainDTO trainDTO) {
        Train train = new Train();
        train.setTrainID(trainDTO.getTrainID());
        train.setSource(trainDTO.getSource());
        train.setDestination(trainDTO.getDestination());
        train.setTravelDate(trainDTO.getTravelDate());
        train.setDepartureTime(trainDTO.getDepartureTime());
        train.setTravelHours(trainDTO.getTravelHours());
        train.setArrivalTime(trainDTO.getArrivalTime());
        train.setPrices(trainDTO.getPrices());
        train.setTicketAvailability(trainDTO.getTicketAvailability());
        train.setTrainName(trainDTO.getTrainName());
        return train;
    }

    private TrainDTO convertToDTO(Train train) {
        TrainDTO trainDTO = new TrainDTO();
        trainDTO.setTrainID(train.getTrainID());
        trainDTO.setSource(train.getSource());
        trainDTO.setDestination(train.getDestination());
        trainDTO.setTravelDate(train.getTravelDate());
        trainDTO.setDepartureTime(train.getDepartureTime());
        trainDTO.setTravelHours(train.getTravelHours());
        trainDTO.setArrivalTime(train.getArrivalTime());
        trainDTO.setPrices(train.getPrices());
        trainDTO.setTicketAvailability(train.getTicketAvailability());
        trainDTO.setTrainName(train.getTrainName());
        return trainDTO;
    }

    private void updateTrainEntity(Train train, TrainDTO trainDTO) {
        train.setSource(trainDTO.getSource());
        train.setDestination(trainDTO.getDestination());
        train.setTravelDate(trainDTO.getTravelDate());
        train.setDepartureTime(trainDTO.getDepartureTime());
        train.setTravelHours(trainDTO.getTravelHours());
        train.setArrivalTime(trainDTO.getArrivalTime());
        train.setPrices(trainDTO.getPrices());
        train.setTicketAvailability(trainDTO.getTicketAvailability());
        train.setTrainName(trainDTO.getTrainName());
    }

@Override
public List<TrainDTO> findAvailableTrainsByRouteAndTime(String source, String destination, 
                                                       LocalDate travelDate, LocalDateTime startTime, 
                                                       LocalDateTime endTime) {
    List<Train> trains = trainRepository.findAvailableTrainsByRouteAndTimeWindow(
        source, destination, travelDate, startTime, endTime);
    
    return trains.stream()
            .filter(train -> train.getTicketAvailability() > 0)
            .map(this::convertToDTO)
            .collect(Collectors.toList());
}

@Override
@Transactional
public boolean bookTicketsAndUpdateAvailability(Integer trainId, int ticketsToBook) {
    Optional<Train> trainOptional = trainRepository.findById(trainId);
    
    if (trainOptional.isEmpty()) {
        throw new TrainNotFoundException("Train not found with ID: " + trainId);
    }
    
    Train train = trainOptional.get();
    
    if (train.getTicketAvailability() < ticketsToBook) {
        return false; // Insufficient tickets
    }
    
    train.setTicketAvailability(train.getTicketAvailability() - ticketsToBook);
    trainRepository.save(train);
    return true;
}

@Override
public List<RouteConnectionDTO> findAvailableRoutesWithConnections(String source, String destination,
                                                                 LocalDate travelDate, int maxStops) {
    List<RouteConnectionDTO> availableRoutes = new ArrayList<>();
    
    // Find direct routes first
    List<TrainDTO> directTrains = findAvailableTrainsByRoute(source, destination, travelDate);
    for (TrainDTO train : directTrains) {
        if (train.getTicketAvailability() > 0) {
            RouteConnectionDTO route = new RouteConnectionDTO();
            route.setRouteId(UUID.randomUUID().toString());
            route.setTrains(Collections.singletonList(train));
            route.setTotalPrice(train.getPrices());
            route.setTotalTravelTime(train.getTravelHours());
            route.setTotalStops(0);
            route.setRouteType("DIRECT");
            route.setRouteDescription(source + " → " + destination + " (Direct)");
            route.setBookable(true);
            availableRoutes.add(route);
        }
    }
    
    // Find connecting routes if needed
    if (maxStops > 0) {
        List<RouteDTO> connectingRoutes = findRoutesWithConnections(source, destination, travelDate, maxStops);
        
        for (RouteDTO routeDTO : connectingRoutes) {
            // Check if all trains in the route have available tickets
            boolean allTrainsAvailable = routeDTO.getTrains().stream()
                    .allMatch(train -> train.getTicketAvailability() > 0);
            
            if (allTrainsAvailable) {
                RouteConnectionDTO route = new RouteConnectionDTO();
                route.setRouteId(UUID.randomUUID().toString());
                route.setTrains(routeDTO.getTrains());
                route.setTotalPrice(routeDTO.getTotalPrice());
                route.setTotalTravelTime(routeDTO.getTotalTravelHours());
                route.setTotalStops(routeDTO.getTotalStops());
                route.setRouteType("CONNECTING");
                route.setRouteDescription(routeDTO.getRouteDescription());
                route.setBookable(true);
                availableRoutes.add(route);
            }
        }
    }
    
    // Sort by total travel time
    availableRoutes.sort(Comparator.comparingDouble(RouteConnectionDTO::getTotalTravelTime));
    
    return availableRoutes;
}
}

