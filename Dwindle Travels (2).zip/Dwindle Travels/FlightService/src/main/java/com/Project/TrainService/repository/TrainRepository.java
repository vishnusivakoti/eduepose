// Add these methods to your TrainRepository interface

package com.Project.TrainService.repository;

import com.Project.TrainService.entity.Train;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.List;

@Repository
public interface TrainRepository extends JpaRepository<Train, Integer> {
    
    // Existing methods...
    List<Train> findBySourceAndDestinationAndTravelDate(String source, String destination, LocalDate travelDate);
    
    List<Train> findBySourceAndDestinationAndTravelDateAndTicketAvailabilityGreaterThan(
            String source, String destination, LocalDate travelDate, int minAvailability);
    
    List<Train> findBySource(String source);
    
    List<Train> findByDestination(String destination);
    
    List<Train> findByTravelDate(LocalDate travelDate);
    
    boolean existsByTrainName(String trainName);
    
    // New methods for enhanced functionality
    
    /**
     * Find available trains by route and time window
     */
    @Query("SELECT t FROM Train t WHERE t.source = :source " +
           "AND t.destination = :destination " +
           "AND t.travelDate = :travelDate " +
           "AND t.departureTime >= :startTime " +
           "AND t.arrivalTime <= :endTime " +
           "AND t.ticketAvailability > 0 " +
           "ORDER BY t.departureTime")
    List<Train> findAvailableTrainsByRouteAndTimeWindow(
            @Param("source") String source,
            @Param("destination") String destination,
            @Param("travelDate") LocalDate travelDate,
            @Param("startTime") LocalDateTime startTime,
            @Param("endTime") LocalDateTime endTime);
    
    /**
     * Find all available trains from a source city on a specific date
     */
    @Query("SELECT t FROM Train t WHERE t.source = :source " +
           "AND t.travelDate = :travelDate " +
           "AND t.ticketAvailability > 0 " +
           "ORDER BY t.departureTime")
    List<Train> findAvailableTrainsFromSource(
            @Param("source") String source,
            @Param("travelDate") LocalDate travelDate);
    
    /**
     * Find trains departing after a specific time from a source
     */
    @Query("SELECT t FROM Train t WHERE t.source = :source " +
           "AND t.travelDate = :travelDate " +
           "AND t.departureTime >= :minDepartureTime " +
           "AND t.ticketAvailability > 0 " +
           "ORDER BY t.departureTime")
    List<Train> findAvailableTrainsFromSourceAfterTime(
            @Param("source") String source,
            @Param("travelDate") LocalDate travelDate,
            @Param("minDepartureTime") LocalDateTime minDepartureTime);
    
    /**
     * Find all unique source cities
     */
    @Query("SELECT DISTINCT t.source FROM Train t ORDER BY t.source")
    List<String> findAllUniqueSources();
    
    /**
     * Find all unique destination cities
     */
    @Query("SELECT DISTINCT t.destination FROM Train t ORDER BY t.destination")
    List<String> findAllUniqueDestinations();
    
    /**
     * Find trains by multiple IDs with availability check
     */
    @Query("SELECT t FROM Train t WHERE t.trainID IN :trainIds " +
           "AND t.ticketAvailability >= :minTickets")
    List<Train> findByTrainIdsWithAvailability(
            @Param("trainIds") List<Integer> trainIds,
            @Param("minTickets") int minTickets);
    
    /**
     * Count available trains for a route
     */
    @Query("SELECT COUNT(t) FROM Train t WHERE t.source = :source " +
           "AND t.destination = :destination " +
           "AND t.travelDate = :travelDate " +
           "AND t.ticketAvailability > 0")
    long countAvailableTrainsForRoute(
            @Param("source") String source,
            @Param("destination") String destination,
            @Param("travelDate") LocalDate travelDate);
    
    /**
     * Find trains with low availability (for alerts)
     */
    @Query("SELECT t FROM Train t WHERE t.ticketAvailability > 0 " +
           "AND t.ticketAvailability <= :threshold " +
           "AND t.travelDate >= :startDate " +
           "ORDER BY t.travelDate, t.departureTime")
    List<Train> findTrainsWithLowAvailability(
            @Param("threshold") int threshold,
            @Param("startDate") LocalDate startDate);
}