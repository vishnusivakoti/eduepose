package com.Project.TrainService.dto;

import java.util.List;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Positive;

public class RouteConnectionDTO {
    private String routeId;
    
    @NotNull(message = "Trains list cannot be null")
    private List<TrainDTO> trains;
    
    @Positive(message = "Total price must be positive")
    private Integer totalPrice;
    
    @Positive(message = "Total travel time must be positive")
    private Double totalTravelTime;
    
    private Integer totalStops;
    private String routeType; // DIRECT, CONNECTING
    private String routeDescription;
    private Boolean bookable;
    
    // Constructors
    public RouteConnectionDTO() {}
    
    public RouteConnectionDTO(List<TrainDTO> trains, Integer totalPrice, 
                            Double totalTravelTime, Integer totalStops, 
                            String routeType, String routeDescription) {
        this.trains = trains;
        this.totalPrice = totalPrice;
        this.totalTravelTime = totalTravelTime;
        this.totalStops = totalStops;
        this.routeType = routeType;
        this.routeDescription = routeDescription;
        this.bookable = true;
    }
    
    // Getters and Setters
    public String getRouteId() { return routeId; }
    public void setRouteId(String routeId) { this.routeId = routeId; }
    
    public List<TrainDTO> getTrains() { return trains; }
    public void setTrains(List<TrainDTO> trains) { this.trains = trains; }
    
    public Integer getTotalPrice() { return totalPrice; }
    public void setTotalPrice(Integer totalPrice) { this.totalPrice = totalPrice; }
    
    public Double getTotalTravelTime() { return totalTravelTime; }
    public void setTotalTravelTime(Double totalTravelTime) { this.totalTravelTime = totalTravelTime; }
    
    public Integer getTotalStops() { return totalStops; }
    public void setTotalStops(Integer totalStops) { this.totalStops = totalStops; }
    
    public String getRouteType() { return routeType; }
    public void setRouteType(String routeType) { this.routeType = routeType; }
    
    public String getRouteDescription() { return routeDescription; }
    public void setRouteDescription(String routeDescription) { this.routeDescription = routeDescription; }
    
    public Boolean getBookable() { return bookable; }
    public void setBookable(Boolean bookable) { this.bookable = bookable; }
}
