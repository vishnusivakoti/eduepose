package com.Project.BookingService.Model;

public enum BookingStatus {
    CONFIRMED, 
    CANCELLED, 
    PENDING, 
    COMPLETED
}
