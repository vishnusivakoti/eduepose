// Enhanced BookingInterface.java
package com.Project.BookingService.Feign;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.List;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import com.Project.BookingService.dto.RouteConnectionDTO;
import com.Project.BookingService.dto.TrainDTO;

@FeignClient(name = "TRAINSERVICE", path = "/train")
public interface BookingInterface {
    
    @GetMapping("/getAllTrains")
    ResponseEntity<List<TrainDTO>> getAllTrains();
    
    @GetMapping("/findTrains/available")
    ResponseEntity<List<TrainDTO>> findAvailableTrainsByRoute(
            @RequestParam String source,
            @RequestParam String destination,
            @RequestParam @DateTimeFormat(iso = DateTimeFormat.ISO.DATE) LocalDate travelDate);
    
    @GetMapping("/findTrains/available/time")
    ResponseEntity<List<TrainDTO>> findAvailableTrainsByRouteAndTime(
            @RequestParam String source,
            @RequestParam String destination,
            @RequestParam @DateTimeFormat(iso = DateTimeFormat.ISO.DATE) LocalDate travelDate,
            @RequestParam @DateTimeFormat(iso = DateTimeFormat.ISO.DATE_TIME) LocalDateTime startTime,
            @RequestParam @DateTimeFormat(iso = DateTimeFormat.ISO.DATE_TIME) LocalDateTime endTime);
    
    @PutMapping("/{trainId}/book")
    ResponseEntity<String> bookTickets(
            @PathVariable Integer trainId, 
            @RequestParam int tickets);
    
    @PostMapping("/book/multiple")
    ResponseEntity<String> bookMultipleTrains(
            @RequestBody List<BookingRequest> bookingRequests);
    
    @GetMapping("/routes/connections/available")
    ResponseEntity<List<RouteConnectionDTO>> findAvailableRoutesWithConnections(
            @RequestParam String source,
            @RequestParam String destination,
            @RequestParam @DateTimeFormat(iso = DateTimeFormat.ISO.DATE) LocalDate travelDate,
            @RequestParam(defaultValue = "2") int maxStops);
    
    @GetMapping("/getById/{id}")
    ResponseEntity<TrainDTO> getTrainById(@PathVariable Integer id);
    
    // Inner class for multiple train booking
    class BookingRequest {
        private Integer trainId;
        private Integer tickets;
        
        public BookingRequest() {}
        
        public BookingRequest(Integer trainId, Integer tickets) {
            this.trainId = trainId;
            this.tickets = tickets;
        }
        
        public Integer getTrainId() { return trainId; }
        public void setTrainId(Integer trainId) { this.trainId = trainId; }
        
        public Integer getTickets() { return tickets; }
        public void setTickets(Integer tickets) { this.tickets = tickets; }
    }
}