package com.Project.BookingService.Dao;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.Project.BookingService.Model.Booking;


@Repository
public interface BookingDao extends JpaRepository<Booking, Integer>{
}
