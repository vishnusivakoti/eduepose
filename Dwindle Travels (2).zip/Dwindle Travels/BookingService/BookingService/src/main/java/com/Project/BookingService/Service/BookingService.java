// Enhanced BookingService.java
package com.Project.BookingService.Service;

import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.Project.BookingService.Dao.BookingDao;
import com.Project.BookingService.Feign.BookingInterface;
import com.Project.BookingService.Model.Booking;
import com.Project.BookingService.dto.BookingRequestDTO;
import com.Project.BookingService.dto.BookingResponseDTO;
import com.Project.BookingService.dto.RouteConnectionDTO;
import com.Project.BookingService.dto.TrainDTO;
import com.Project.BookingService.Model.*;

@Service
@Transactional
public class BookingService {
    
    private static final Logger logger = LoggerFactory.getLogger(BookingService.class);
    
    @Autowired
    private BookingDao bookingDao;
    
    @Autowired
    private BookingInterface trainServiceClient;

    public ResponseEntity<List<TrainDTO>> getAllTrains() {
        try {
            ResponseEntity<List<TrainDTO>> response = trainServiceClient.getAllTrains();
            return ResponseEntity.ok(response.getBody());
        } catch (Exception e) {
            logger.error("Error fetching all trains: ", e);
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).build();
        }
    }

    public ResponseEntity<List<RouteConnectionDTO>> findAvailableRoutes(String source, String destination, 
                                                                      String travelDate, Integer maxStops) {
        try {
            ResponseEntity<List<RouteConnectionDTO>> response = trainServiceClient
                    .findAvailableRoutesWithConnections(source, destination, 
                            java.time.LocalDate.parse(travelDate), 
                            maxStops != null ? maxStops : 2);
            return ResponseEntity.ok(response.getBody());
        } catch (Exception e) {
            logger.error("Error fetching available routes: ", e);
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).build();
        }
    }

    @Transactional
    public ResponseEntity<BookingResponseDTO> bookDirectTrain(BookingRequestDTO bookingRequest) {
        try {
            // Validate booking request
            if (!validateBookingRequest(bookingRequest)) {
                return ResponseEntity.badRequest()
                        .body(createErrorResponse("Invalid booking request"));
            }

            // Find available trains
            List<TrainDTO> availableTrains = findAvailableTrainsForBooking(bookingRequest);
            
            if (availableTrains.isEmpty()) {
                return ResponseEntity.badRequest()
                        .body(createErrorResponse("No available trains found for the specified route and date"));
            }

            // Select the first available train
            TrainDTO selectedTrain = availableTrains.get(0);
            
            // Check ticket availability
            if (selectedTrain.getTicketAvailability() < bookingRequest.getNoOfTickets()) {
                return ResponseEntity.badRequest()
                        .body(createErrorResponse("Insufficient tickets available. Available: " 
                                + selectedTrain.getTicketAvailability()));
            }

            // Book tickets in train service
            ResponseEntity<String> bookingResponse = trainServiceClient
                    .bookTickets(selectedTrain.getTrainID(), bookingRequest.getNoOfTickets());
            
            if (!bookingResponse.getStatusCode().is2xxSuccessful()) {
                return ResponseEntity.badRequest()
                        .body(createErrorResponse("Failed to book tickets in train service"));
            }

            // Create and save booking
            Booking booking = createBookingFromRequest(bookingRequest);
            booking.setTrainIdsList(List.of(selectedTrain.getTrainID()));
            booking.setTotalAmount(selectedTrain.getPrices() * bookingRequest.getNoOfTickets());
            booking.setRouteType(RouteType.DIRECT);
            booking.setRouteDescription(bookingRequest.getSource() + " → " + bookingRequest.getDestination());
            
            Booking savedBooking = bookingDao.save(booking);
            
            BookingResponseDTO response = convertToResponseDTO(savedBooking);
            response.setTrainIds(List.of(selectedTrain.getTrainID()));
            
            logger.info("Direct train booking successful - Booking ID: {}, Reference: {}", 
                    savedBooking.getBookingId(), savedBooking.getBookingReference());
            
            return ResponseEntity.ok(response);
            
        } catch (Exception e) {
            logger.error("Error in direct train booking: ", e);
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
                    .body(createErrorResponse("Internal server error occurred while booking"));
        }
    }

    @Transactional
    public ResponseEntity<BookingResponseDTO> bookRouteWithConnections(BookingRequestDTO bookingRequest) {
        try {
            // Validate booking request
            if (!validateBookingRequest(bookingRequest)) {
                return ResponseEntity.badRequest()
                        .body(createErrorResponse("Invalid booking request"));
            }

            // Find available routes with connections
            ResponseEntity<List<RouteConnectionDTO>> routesResponse = trainServiceClient
                    .findAvailableRoutesWithConnections(
                            bookingRequest.getSource(), 
                            bookingRequest.getDestination(),
                            bookingRequest.getTravelDate(), 
                            2); // Max 2 stops
            
            if (!routesResponse.getStatusCode().is2xxSuccessful() || 
                routesResponse.getBody() == null || routesResponse.getBody().isEmpty()) {
                return ResponseEntity.badRequest()
                        .body(createErrorResponse("No available routes found with connections"));
            }

            // Find the route if routeId is specified
            RouteConnectionDTO selectedRoute;
            if (bookingRequest.getRouteId() != null) {
                selectedRoute = routesResponse.getBody().stream()
                        .filter(route -> route.getRouteId().equals(bookingRequest.getRouteId()))
                        .findFirst()
                        .orElse(null);
                
                if (selectedRoute == null) {
                    return ResponseEntity.badRequest()
                            .body(createErrorResponse("Specified route not found"));
                }
            } else {
                // Select the first available route
                selectedRoute = routesResponse.getBody().get(0);
            }

            // Check if route is bookable
            if (!selectedRoute.getBookable()) {
                return ResponseEntity.badRequest()
                        .body(createErrorResponse("Selected route is not available for booking"));
            }

            // Book all trains in the route
            List<Integer> trainIds = selectedRoute.getTrains().stream()
                    .map(TrainDTO::getTrainID)
                    .collect(Collectors.toList());
            
            boolean allBookingsSuccessful = true;
            for (TrainDTO train : selectedRoute.getTrains()) {
                ResponseEntity<String> bookingResponse = trainServiceClient
                        .bookTickets(train.getTrainID(), bookingRequest.getNoOfTickets());
                
                if (!bookingResponse.getStatusCode().is2xxSuccessful()) {
                    allBookingsSuccessful = false;
                    logger.error("Failed to book train ID: {}", train.getTrainID());
                    break;
                }
            }

            if (!allBookingsSuccessful) {
                // Rollback any successful bookings (this would need additional implementation)
                return ResponseEntity.badRequest()
                        .body(createErrorResponse("Failed to book one or more trains in the route"));
            }

            // Create and save booking
            Booking booking = createBookingFromRequest(bookingRequest);
            booking.setTrainIdsList(trainIds);
            booking.setTotalAmount(selectedRoute.getTotalPrice() * bookingRequest.getNoOfTickets());
            booking.setRouteType(RouteType.CONNECTING);
            booking.setRouteDescription(selectedRoute.getRouteDescription());
            booking.setRouteId(selectedRoute.getRouteId());
            
            Booking savedBooking = bookingDao.save(booking);
            
            BookingResponseDTO response = convertToResponseDTO(savedBooking);
            response.setTrainIds(trainIds);
            
            logger.info("Route booking successful - Booking ID: {}, Reference: {}, Trains: {}", 
                    savedBooking.getBookingId(), savedBooking.getBookingReference(), trainIds);
            
            return ResponseEntity.ok(response);
            
        } catch (Exception e) {
            logger.error("Error in route booking: ", e);
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
                    .body(createErrorResponse("Internal server error occurred while booking route"));
        }
    }

    public ResponseEntity<BookingResponseDTO> getBookingById(Integer bookingId) {
        try {
            Optional<Booking> bookingOpt = bookingDao.findById(bookingId);
            
            if (bookingOpt.isEmpty()) {
                return ResponseEntity.status(HttpStatus.NOT_FOUND)
                        .body(createErrorResponse("Booking not found"));
            }
            
            Booking booking = bookingOpt.get();
            BookingResponseDTO response = convertToResponseDTO(booking);
            response.setTrainIds(booking.getTrainIdsList());
            
            return ResponseEntity.ok(response);
            
        } catch (Exception e) {
            logger.error("Error fetching booking by ID: ", e);
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
                    .body(createErrorResponse("Internal server error"));
        }
    }

    @Transactional
    public ResponseEntity<String> cancelBooking(Integer bookingId, Integer ticketsToCancel) {
        try {
            Optional<Booking> bookingOpt = bookingDao.findById(bookingId);
            
            if (bookingOpt.isEmpty()) {
                return ResponseEntity.status(HttpStatus.NOT_FOUND)
                        .body("Booking not found");
            }
            
            Booking booking = bookingOpt.get();
            
            if (booking.getBookingStatus() == BookingStatus.CANCELLED) {
                return ResponseEntity.badRequest()
                        .body("Booking is already cancelled");
            }
            
            if (ticketsToCancel > booking.getNumberOfTickets()) {
                return ResponseEntity.badRequest()
                        .body("Cannot cancel more tickets than booked");
            }
            
            if (ticketsToCancel.equals(booking.getNumberOfTickets())) {
                // Cancel entire booking
                booking.setBookingStatus(BookingStatus.CANCELLED);
                bookingDao.save(booking);
                
                logger.info("Booking cancelled completely - ID: {}", bookingId);
                return ResponseEntity.ok("Booking cancelled successfully");
            } else {
                // Partial cancellation
                booking.setNumberOfTickets(booking.getNumberOfTickets() - ticketsToCancel);
                booking.setTotalAmount((booking.getTotalAmount() / (booking.getNumberOfTickets() + ticketsToCancel)) 
                        * booking.getNumberOfTickets());
                bookingDao.save(booking);
                
                logger.info("Partial booking cancellation - ID: {}, Cancelled: {}", bookingId, ticketsToCancel);
                return ResponseEntity.ok("Booking updated successfully. Tickets cancelled: " + ticketsToCancel);
            }
            
        } catch (Exception e) {
            logger.error("Error cancelling booking: ", e);
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
                    .body("Internal server error occurred while cancelling booking");
        }
    }

    // Helper methods
    private List<TrainDTO> findAvailableTrainsForBooking(BookingRequestDTO bookingRequest) {
        if (bookingRequest.getPreferredDepartureTime() != null && 
            bookingRequest.getPreferredArrivalTime() != null) {
            return trainServiceClient.findAvailableTrainsByRouteAndTime(
                    bookingRequest.getSource(),
                    bookingRequest.getDestination(),
                    bookingRequest.getTravelDate(),
                    bookingRequest.getPreferredDepartureTime(),
                    bookingRequest.getPreferredArrivalTime()
            ).getBody();
        } else {
            return trainServiceClient.findAvailableTrainsByRoute(
                    bookingRequest.getSource(),
                    bookingRequest.getDestination(),
                    bookingRequest.getTravelDate()
            ).getBody();
        }
    }

    private boolean validateBookingRequest(BookingRequestDTO request) {
        return request != null &&
               request.getName() != null && !request.getName().trim().isEmpty() &&
               request.getAge() != null && request.getAge() > 0 && request.getAge() <= 120 &&
               request.getGender() != null && !request.getGender().trim().isEmpty() &&
               request.getNoOfTickets() != null && request.getNoOfTickets() > 0 && request.getNoOfTickets() <= 6 &&
               request.getTravelDate() != null && !request.getTravelDate().isBefore(java.time.LocalDate.now()) &&
               request.getSource() != null && !request.getSource().trim().isEmpty() &&
               request.getDestination() != null && !request.getDestination().trim().isEmpty() &&
               !request.getSource().equalsIgnoreCase(request.getDestination());
    }

    private Booking createBookingFromRequest(BookingRequestDTO request) {
        Booking booking = new Booking();
        booking.setPassengerName(request.getName().trim());
        booking.setAge(request.getAge());
        booking.setGender(request.getGender().toUpperCase());
        booking.setNumberOfTickets(request.getNoOfTickets());
        booking.setTravelDate(request.getTravelDate());
        booking.setSource(request.getSource().trim());
        booking.setDestination(request.getDestination().trim());
        booking.setPreferredDepartureTime(request.getPreferredDepartureTime());
        booking.setPreferredArrivalTime(request.getPreferredArrivalTime());
        booking.setBookingStatus(BookingStatus.CONFIRMED);
        booking.setBookingDateTime(LocalDateTime.now());
        return booking;
    }

    private BookingResponseDTO convertToResponseDTO(Booking booking) {
        BookingResponseDTO response = new BookingResponseDTO();
        response.setBookingId(booking.getBookingId());
        response.setBookingReference(booking.getBookingReference());
        response.setPassengerName(booking.getPassengerName());
        response.setAge(booking.getAge());
        response.setGender(booking.getGender());
        response.setNumberOfTickets(booking.getNumberOfTickets());
        response.setTravelDate(booking.getTravelDate());
        response.setSource(booking.getSource());
        response.setDestination(booking.getDestination());
        response.setTotalAmount(booking.getTotalAmount());
        response.setBookingStatus(booking.getBookingStatus().name());
        response.setBookingDateTime(booking.getBookingDateTime());
        response.setRouteDescription(booking.getRouteDescription());
        response.setRouteType(booking.getRouteType().name());
        return response;
    }

    private BookingResponseDTO createErrorResponse(String errorMessage) {
        BookingResponseDTO response = new BookingResponseDTO();
        response.setBookingStatus("ERROR");
        // You might want to add an error message field to BookingResponseDTO
        return response;
    }
    
    
}