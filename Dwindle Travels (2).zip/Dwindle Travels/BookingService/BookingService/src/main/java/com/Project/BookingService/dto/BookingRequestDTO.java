package com.Project.BookingService.dto;

import java.time.LocalDate;
import java.time.LocalDateTime;
import jakarta.validation.constraints.*;

public class BookingRequestDTO {
    @NotBlank(message = "Name is required")
    @Size(min = 2, max = 50, message = "Name must be between 2 and 50 characters")
    private String name;
    
    @Min(value = 1, message = "Age must be at least 1")
    @Max(value = 120, message = "Age must be at most 120")
    private Integer age;
    
    @NotBlank(message = "Gender is required")
    @Pattern(regexp = "^(MALE|FEMALE|OTHER)$", message = "Gender must be MALE, FEMALE, or OTHER")
    private String gender;
    
    @Min(value = 1, message = "Number of tickets must be at least 1")
    @Max(value = 6, message = "Cannot book more than 6 tickets per booking")
    private Integer noOfTickets;
    
    @NotNull(message = "Travel date is required")
    @FutureOrPresent(message = "Travel date cannot be in the past")
    private LocalDate travelDate;
    
    @NotBlank(message = "Source is required")
    private String source;
    
    @NotBlank(message = "Destination is required")
    private String destination;
    
    private LocalDateTime preferredDepartureTime;
    private LocalDateTime preferredArrivalTime;
    
    // For route-based booking
    private String routeId;
    private Boolean isRouteBooking = false;
    
    // Constructors
    public BookingRequestDTO() {}
    
    // Getters and Setters
    public String getName() { return name; }
    public void setName(String name) { this.name = name; }
    
    public Integer getAge() { return age; }
    public void setAge(Integer age) { this.age = age; }
    
    public String getGender() { return gender; }
    public void setGender(String gender) { this.gender = gender; }
    
    public Integer getNoOfTickets() { return noOfTickets; }
    public void setNoOfTickets(Integer noOfTickets) { this.noOfTickets = noOfTickets; }
    
    public LocalDate getTravelDate() { return travelDate; }
    public void setTravelDate(LocalDate travelDate) { this.travelDate = travelDate; }
    
    public String getSource() { return source; }
    public void setSource(String source) { this.source = source; }
    
    public String getDestination() { return destination; }
    public void setDestination(String destination) { this.destination = destination; }
    
    public LocalDateTime getPreferredDepartureTime() { return preferredDepartureTime; }
    public void setPreferredDepartureTime(LocalDateTime preferredDepartureTime) { 
        this.preferredDepartureTime = preferredDepartureTime; 
    }
    
    public LocalDateTime getPreferredArrivalTime() { return preferredArrivalTime; }
    public void setPreferredArrivalTime(LocalDateTime preferredArrivalTime) { 
        this.preferredArrivalTime = preferredArrivalTime; 
    }
    
    public String getRouteId() { return routeId; }
    public void setRouteId(String routeId) { this.routeId = routeId; }
    
    public Boolean getIsRouteBooking() { return isRouteBooking; }
    public void setIsRouteBooking(Boolean isRouteBooking) { this.isRouteBooking = isRouteBooking; }
}
