package com.Project.BookingService.dto;

import java.util.List;

public class RouteDTO {
    private List<TrainDTO> trains;
    private int totalPrice;
    private double totalTravelHours;
    private String routeDescription;
    private int totalStops;

    // Constructors
    public RouteDTO() {}

    public RouteDTO(List<TrainDTO> trains, int totalPrice, double totalTravelHours, 
                    String routeDescription, int totalStops) {
        this.trains = trains;
        this.totalPrice = totalPrice;
        this.totalTravelHours = totalTravelHours;
        this.routeDescription = routeDescription;
        this.totalStops = totalStops;
    }

    // Getters and Setters
    public List<TrainDTO> getTrains() { return trains; }
    public void setTrains(List<TrainDTO> trains) { this.trains = trains; }
    
    public int getTotalPrice() { return totalPrice; }
    public void setTotalPrice(int totalPrice) { this.totalPrice = totalPrice; }
    
    public double getTotalTravelHours() { return totalTravelHours; }
    public void setTotalTravelHours(double totalTravelHours) { this.totalTravelHours = totalTravelHours; }
    
    public String getRouteDescription() { return routeDescription; }
    public void setRouteDescription(String routeDescription) { this.routeDescription = routeDescription; }
    
    public int getTotalStops() { return totalStops; }
    public void setTotalStops(int totalStops) { this.totalStops = totalStops; }
}

