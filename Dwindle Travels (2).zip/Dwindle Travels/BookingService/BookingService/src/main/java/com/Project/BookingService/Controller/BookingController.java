// Enhanced BookingController.java
package com.Project.BookingService.Controller;

import java.util.List;

import jakarta.validation.Valid;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.*;

import com.Project.BookingService.Service.BookingService;
import com.Project.BookingService.dto.BookingRequestDTO;
import com.Project.BookingService.dto.BookingResponseDTO;
import com.Project.BookingService.dto.RouteConnectionDTO;
import com.Project.BookingService.dto.TrainDTO;

@RestController
@RequestMapping("/api/booking")
@CrossOrigin(origins = "*")
public class BookingController {
    
    private static final Logger logger = LoggerFactory.getLogger(BookingController.class);
    
    @Autowired
    private BookingService bookingService;

    /**
     * Get all available trains
     */
    @GetMapping("/trains/all")
    public ResponseEntity<List<TrainDTO>> getAllTrains() {
        logger.info("Request received to fetch all trains");
        return bookingService.getAllTrains();
    }

    /**
     * Find available routes including connections between source and destination
     */
    @GetMapping("/routes/search")
    public ResponseEntity<List<RouteConnectionDTO>> searchAvailableRoutes(
            @RequestParam String source,
            @RequestParam String destination,
            @RequestParam @DateTimeFormat(iso = DateTimeFormat.ISO.DATE) String travelDate,
            @RequestParam(defaultValue = "2") Integer maxStops) {
        
        logger.info("Searching routes from {} to {} on {} with max {} stops", 
                source, destination, travelDate, maxStops);
        
        if (source == null || source.trim().isEmpty()) {
            return ResponseEntity.badRequest().build();
        }
        if (destination == null || destination.trim().isEmpty()) {
            return ResponseEntity.badRequest().build();
        }
        if (source.equalsIgnoreCase(destination)) {
            return ResponseEntity.badRequest().build();
        }
        
        return bookingService.findAvailableRoutes(source, destination, travelDate, maxStops);
    }

    /**
     * Book a direct train ticket
     */
    @PostMapping("/book/direct")
    public ResponseEntity<BookingResponseDTO> bookDirectTrain(
            @Valid @RequestBody BookingRequestDTO bookingRequest,
            BindingResult bindingResult) {
        
        if (bindingResult.hasErrors()) {
            logger.warn("Validation errors in booking request: {}", bindingResult.getAllErrors());
            BookingResponseDTO errorResponse = new BookingResponseDTO();
            errorResponse.setBookingStatus("VALIDATION_ERROR");
            return ResponseEntity.badRequest().body(errorResponse);
        }
        
        logger.info("Direct booking request received for {} from {} to {} on {}", 
                bookingRequest.getName(), bookingRequest.getSource(), 
                bookingRequest.getDestination(), bookingRequest.getTravelDate());
        
        bookingRequest.setIsRouteBooking(false);
        return bookingService.bookDirectTrain(bookingRequest);
    }

    /**
     * Book a route with connections
     */
    @PostMapping("/book/route")
    public ResponseEntity<BookingResponseDTO> bookRouteWithConnections(
            @Valid @RequestBody BookingRequestDTO bookingRequest,
            BindingResult bindingResult) {
        
        if (bindingResult.hasErrors()) {
            logger.warn("Validation errors in route booking request: {}", bindingResult.getAllErrors());
            BookingResponseDTO errorResponse = new BookingResponseDTO();
            errorResponse.setBookingStatus("VALIDATION_ERROR");
            return ResponseEntity.badRequest().body(errorResponse);
        }
        
        if (bookingRequest.getRouteId() == null || bookingRequest.getRouteId().trim().isEmpty()) {
            logger.warn("Route ID is required for route booking");
            BookingResponseDTO errorResponse = new BookingResponseDTO();
            errorResponse.setBookingStatus("ROUTE_ID_REQUIRED");
            return ResponseEntity.badRequest().body(errorResponse);
        }
        
        logger.info("Route booking request received for {} using route ID: {}", 
                bookingRequest.getName(), bookingRequest.getRouteId());
        
        bookingRequest.setIsRouteBooking(true);
        return bookingService.bookRouteWithConnections(bookingRequest);
    }

    /**
     * Get booking details by booking ID
     */
    @GetMapping("/{bookingId}")
    public ResponseEntity<BookingResponseDTO> getBookingById(@PathVariable Integer bookingId) {
        logger.info("Fetching booking details for ID: {}", bookingId);
        
        if (bookingId == null || bookingId <= 0) {
            return ResponseEntity.badRequest().build();
        }
        
        return bookingService.getBookingById(bookingId);
    }

    /**
     * Cancel booking (full or partial)
     */
    @PutMapping("/{bookingId}/cancel")
    public ResponseEntity<String> cancelBooking(
            @PathVariable Integer bookingId,
            @RequestParam Integer ticketsToCancel) {
        
        logger.info("Cancellation request for booking ID: {}, tickets: {}", bookingId, ticketsToCancel);
        
        if (bookingId == null || bookingId <= 0) {
            return ResponseEntity.badRequest().body("Invalid booking ID");
        }
        
        if (ticketsToCancel == null || ticketsToCancel <= 0) {
            return ResponseEntity.badRequest().body("Number of tickets to cancel must be positive");
        }
        
        return bookingService.cancelBooking(bookingId, ticketsToCancel);
    }

    /**
     * Health check endpoint
     */
    @GetMapping("/health")
    public ResponseEntity<String> healthCheck() {
        return ResponseEntity.ok("Booking Service is running");
    }

    // Exception handlers
    @ExceptionHandler(IllegalArgumentException.class)
    public ResponseEntity<String> handleIllegalArgumentException(IllegalArgumentException e) {
        logger.error("Illegal argument exception: ", e);
        return ResponseEntity.badRequest().body(e.getMessage());
    }

    @ExceptionHandler(Exception.class)
    public ResponseEntity<String> handleGenericException(Exception e) {
        logger.error("Unexpected error: ", e);
        return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
                .body("An unexpected error occurred. Please try again later.");
    }
}