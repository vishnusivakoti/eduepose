// Enhanced Booking.java Entity
package com.Project.BookingService.Model;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.List;
import jakarta.persistence.*;
import jakarta.validation.constraints.*;

@Entity
@Table(name = "bookings", indexes = {
    @Index(name = "idx_booking_reference", columnList = "bookingReference", unique = true),
    @Index(name = "idx_travel_date", columnList = "travelDate"),
    @Index(name = "idx_booking_status", columnList = "bookingStatus")
})
public class Booking {
    
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "booking_id")
    private Integer bookingId;
    
    @Column(name = "booking_reference", unique = true, nullable = false, length = 20)
    private String bookingReference;
    
    @NotBlank(message = "Passenger name is required")
    @Size(min = 2, max = 100, message = "Name must be between 2 and 100 characters")
    @Column(name = "passenger_name", nullable = false, length = 100)
    private String passengerName;
    
    @Min(value = 1, message = "Age must be at least 1")
    @Max(value = 120, message = "Age must be at most 120")
    @Column(name = "age", nullable = false)
    private Integer age;
    
    @NotBlank(message = "Gender is required")
    @Pattern(regexp = "^(MALE|FEMALE|OTHER)$", message = "Gender must be MALE, FEMALE, or OTHER")
    @Column(name = "gender", nullable = false, length = 10)
    private String gender;
    
    @Min(value = 1, message = "Number of tickets must be at least 1")
    @Max(value = 6, message = "Cannot book more than 6 tickets")
    @Column(name = "number_of_tickets", nullable = false)
    private Integer numberOfTickets;
    
    @NotNull(message = "Travel date is required")
    @Column(name = "travel_date", nullable = false)
    private LocalDate travelDate;
    
    @NotBlank(message = "Source is required")
    @Column(name = "source", nullable = false, length = 100)
    private String source;
    
    @NotBlank(message = "Destination is required")
    @Column(name = "destination", nullable = false, length = 100)
    private String destination;
    
    @Column(name = "preferred_departure_time")
    private LocalDateTime preferredDepartureTime;
    
    @Column(name = "preferred_arrival_time")
    private LocalDateTime preferredArrivalTime;
    
    // Store multiple train IDs as comma-separated string for connecting routes
    @Column(name = "train_ids", length = 500)
    private String trainIds;
    
    @Column(name = "total_amount")
    private Integer totalAmount;
    
    @Enumerated(EnumType.STRING)
    @Column(name = "booking_status", nullable = false, length = 20)
    private BookingStatus bookingStatus = BookingStatus.CONFIRMED;
    
    @Column(name = "booking_date_time", nullable = false)
    private LocalDateTime bookingDateTime;
    
    @Column(name = "route_description", length = 500)
    private String routeDescription;
    
    @Enumerated(EnumType.STRING)
    @Column(name = "route_type", length = 20)
    private RouteType routeType = RouteType.DIRECT;
    
    @Column(name = "route_id")
    private String routeId;
    
    @Version
    private Long version;
    
    // Constructors
    public Booking() {
        this.bookingDateTime = LocalDateTime.now();
        this.bookingStatus = BookingStatus.CONFIRMED;
    }
    
    public Booking(String passengerName, Integer age, String gender, 
                  Integer numberOfTickets, LocalDate travelDate, 
                  String source, String destination) {
        this();
        this.passengerName = passengerName;
        this.age = age;
        this.gender = gender;
        this.numberOfTickets = numberOfTickets;
        this.travelDate = travelDate;
        this.source = source;
        this.destination = destination;
    }
    
    // Helper methods
    public List<Integer> getTrainIdsList() {
        if (trainIds == null || trainIds.trim().isEmpty()) {
            return List.of();
        }
        return List.of(trainIds.split(","))
                .stream()
                .map(String::trim)
                .map(Integer::parseInt)
                .toList();
    }
    
    public void setTrainIdsList(List<Integer> trainIdsList) {
        if (trainIdsList == null || trainIdsList.isEmpty()) {
            this.trainIds = null;
        } else {
            this.trainIds = trainIdsList.stream()
                    .map(String::valueOf)
                    .reduce((a, b) -> a + "," + b)
                    .orElse("");
        }
    }
    
    @PrePersist
    protected void onCreate() {
        bookingDateTime = LocalDateTime.now();
        if (bookingReference == null) {
            generateBookingReference();
        }
    }
    
    private void generateBookingReference() {
        // Generate booking reference: BK + timestamp + random 4 digits
        long timestamp = System.currentTimeMillis() % 100000;
        int random = (int) (Math.random() * 9000) + 1000;
        this.bookingReference = "BK" + timestamp + random;
    }
    
    // Getters and Setters
    public Integer getBookingId() { return bookingId; }
    public void setBookingId(Integer bookingId) { this.bookingId = bookingId; }
    
    public String getBookingReference() { return bookingReference; }
    public void setBookingReference(String bookingReference) { this.bookingReference = bookingReference; }
    
    public String getPassengerName() { return passengerName; }
    public void setPassengerName(String passengerName) { this.passengerName = passengerName; }
    
    public Integer getAge() { return age; }
    public void setAge(Integer age) { this.age = age; }
    
    public String getGender() { return gender; }
    public void setGender(String gender) { this.gender = gender; }
    
    public Integer getNumberOfTickets() { return numberOfTickets; }
    public void setNumberOfTickets(Integer numberOfTickets) { this.numberOfTickets = numberOfTickets; }
    
    public LocalDate getTravelDate() { return travelDate; }
    public void setTravelDate(LocalDate travelDate) { this.travelDate = travelDate; }
    
    public String getSource() { return source; }
    public void setSource(String source) { this.source = source; }
    
    public String getDestination() { return destination; }
    public void setDestination(String destination) { this.destination = destination; }
    
    public LocalDateTime getPreferredDepartureTime() { return preferredDepartureTime; }
    public void setPreferredDepartureTime(LocalDateTime preferredDepartureTime) { 
        this.preferredDepartureTime = preferredDepartureTime; 
    }
    
    public LocalDateTime getPreferredArrivalTime() { return preferredArrivalTime; }
    public void setPreferredArrivalTime(LocalDateTime preferredArrivalTime) { 
        this.preferredArrivalTime = preferredArrivalTime; 
    }
    
    public String getTrainIds() { return trainIds; }
    public void setTrainIds(String trainIds) { this.trainIds = trainIds; }
    
    public Integer getTotalAmount() { return totalAmount; }
    public void setTotalAmount(Integer totalAmount) { this.totalAmount = totalAmount; }
    
    public BookingStatus getBookingStatus() { return bookingStatus; }
    public void setBookingStatus(BookingStatus bookingStatus) { this.bookingStatus = bookingStatus; }
    
    public LocalDateTime getBookingDateTime() { return bookingDateTime; }
    public void setBookingDateTime(LocalDateTime bookingDateTime) { this.bookingDateTime = bookingDateTime; }
    
    public String getRouteDescription() { return routeDescription; }
    public void setRouteDescription(String routeDescription) { this.routeDescription = routeDescription; }
    
    public RouteType getRouteType() { return routeType; }
    public void setRouteType(RouteType routeType) { this.routeType = routeType; }
    
    public String getRouteId() { return routeId; }
    public void setRouteId(String routeId) { this.routeId = routeId; }
    
    public Long getVersion() { return version; }
    public void setVersion(Long version) { this.version = version; }
}
