package com.Project.BookingService.Model;

import java.time.LocalDate;
import java.time.LocalDateTime;

import jakarta.persistence.Column;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;

@Table(name = "Traininfo")
public class Train {
	 @Id
	    @GeneratedValue(strategy = GenerationType.IDENTITY)
	    @Column(name = "TrainID")
	    private Integer trainID;

	    @Column(name = "Source")
	    private String source;

	    @Column(name = "Destination")
	    private String destination;

	    @Column(name = "travel_date")
	    private LocalDate travelDate;

	    @Column(name = "departure_time")
	    private LocalDateTime departureTime;

	    @Column(name = "travel_hours")
	    private double travelHours;

	    @Column(name = "arrival_time")
	    private LocalDateTime arrivalTime;
	    
	    @Column(name = "prices")
	    private int prices;
	    
	    @Column(name = "ticket_availability")
	    private int ticket_availability;


		public Integer getTrainID() {
			return trainID;
		}

		public void setTrainID(Integer trainID) {
			this.trainID = trainID;
		}

		public String getSource() {
			return source;
		}

		public void setSource(String source) {
			this.source = source;
		}

		public String getDestination() {
			return destination;
		}

		public void setDestination(String destination) {
			this.destination = destination;
		}

		public LocalDate getTravelDate() {
			return travelDate;
		}

		public void setTravelDate(LocalDate travelDate) {
			this.travelDate = travelDate;
		}

		public LocalDateTime getDepartureTime() {
			return departureTime;
		}

		public void setDepartureTime(LocalDateTime departureTime) {
			this.departureTime = departureTime;
		}

		public double getTravelHours() {
			return travelHours;
		}

		public void setTravelHours(double travelHours) {
			this.travelHours = travelHours;
		}

		public LocalDateTime getArrivalTime() {
			return arrivalTime;
		}

		public void setArrivalTime(LocalDateTime arrivalTime) {
			this.arrivalTime = arrivalTime;
		}

		public int getPrices() {
			return prices;
		}

		public void setPrices(int prices) {
			this.prices = prices;
		}

		public int getTicket_availability() {
			return ticket_availability;
		}

		public void setTicket_availability(int ticket_availability) {
			this.ticket_availability = ticket_availability;
		}

		public Train() {
			super();
		}

		public Train(Integer trainID, String source, String destination, LocalDate travelDate,
				LocalDateTime departureTime, double travelHours, LocalDateTime arrivalTime, int prices,
				int ticket_availability) {
			super();
			this.trainID = trainID;
			this.source = source;
			this.destination = destination;
			this.travelDate = travelDate;
			this.departureTime = departureTime;
			this.travelHours = travelHours;
			this.arrivalTime = arrivalTime;
			this.prices = prices;
			this.ticket_availability = ticket_availability;
		}
}
