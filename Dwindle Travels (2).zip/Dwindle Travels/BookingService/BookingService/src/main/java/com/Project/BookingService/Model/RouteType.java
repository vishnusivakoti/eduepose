package com.Project.BookingService.Model;

public enum RouteType {
    DIRECT, 
    CONNECTING
}
