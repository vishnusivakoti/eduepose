package com.Project.CancellationService.Controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestBody;

import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.Project.CancellationService.Model.Cancellation;
import com.Project.CancellationService.Service.CancellationService;

@RestController
@RequestMapping("/cancellation")
public class CancellationController {
	@Autowired
	CancellationService service;
	@PostMapping("/cancel")
	public ResponseEntity<String> cancelTicket(@RequestBody Cancellation cancellation){
		return service.cancelticket(cancellation);
	}

}
