package com.Project.CancellationService.Feign;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PutMapping;

@FeignClient("TRAINSERVICE")
public interface CancellationInterfaceTrainService {
	@PutMapping("train/addseats/{trainID}/{seats}")
	public ResponseEntity<String> addseats(@PathVariable int trainID,@PathVariable int seats);
}
