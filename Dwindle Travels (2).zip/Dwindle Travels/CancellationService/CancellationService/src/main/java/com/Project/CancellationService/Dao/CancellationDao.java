package com.Project.CancellationService.Dao;

import org.springframework.data.jpa.repository.JpaRepository;

import com.Project.CancellationService.Model.Cancellation;
import org.springframework.stereotype.Repository;

@Repository
public interface CancellationDao extends JpaRepository<Cancellation, Integer>{

}
