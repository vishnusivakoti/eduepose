package com.Project.CancellationService;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.cloud.openfeign.EnableFeignClients;

@SpringBootApplication
@EnableFeignClients
public class CancellationServiceApplication {

	public static void main(String[] args) {
		SpringApplication.run(CancellationServiceApplication.class, args);
	}

}
