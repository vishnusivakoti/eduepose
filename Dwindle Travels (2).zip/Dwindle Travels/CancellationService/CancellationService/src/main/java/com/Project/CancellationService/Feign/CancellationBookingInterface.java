package com.Project.CancellationService.Feign;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PutMapping;

import com.Project.CancellationService.Model.Booking;



@FeignClient("BOOKINGSERVICE")
public interface CancellationBookingInterface {
	@GetMapping("booking/bookingbyId/{custId}")
	public ResponseEntity<Booking> getbyid(@PathVariable int custId);
	@PutMapping("booking/updatebyid/{custId}/{nooftickets}")
	public ResponseEntity<String> updatebyid(@PathVariable int custId,@PathVariable int nooftickets);
}
