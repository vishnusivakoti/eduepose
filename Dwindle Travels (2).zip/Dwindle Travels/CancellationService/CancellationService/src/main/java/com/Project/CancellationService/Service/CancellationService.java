package com.Project.CancellationService.Service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import com.Project.CancellationService.Dao.CancellationDao;
import com.Project.CancellationService.Feign.CancellationBookingInterface;
import com.Project.CancellationService.Feign.CancellationInterfaceTrainService;
import com.Project.CancellationService.Model.Booking;
import com.Project.CancellationService.Model.Cancellation;

@Service
public class CancellationService {
	@Autowired
	CancellationDao dao;
	@Autowired
	CancellationBookingInterface bi;
	@Autowired
	CancellationInterfaceTrainService ti;
	public ResponseEntity<String> cancelticket(Cancellation cancellation) {
		try {
			Booking b = bi.getbyid(cancellation.getTicketid()).getBody();
	        if (b != null && b.getNoOfTickets() >= cancellation.getNooftickets()) {
	        	ti.addseats(b.getTrainID(), cancellation.getNooftickets());
	        	bi.updatebyid(cancellation.getTicketid(),cancellation.getNooftickets());
	        	dao.save(cancellation);
	            return new ResponseEntity<>("Ticket Cancelled Sucessfully!", HttpStatus.OK);
	        } else {
	            return new ResponseEntity<>("Please check your cancelletion ticket information", HttpStatus.NOT_FOUND);
	        }
	    } catch (Exception e) {
	        e.printStackTrace();
	        return new ResponseEntity<>("There is an error in cancelling your Ticket.", HttpStatus.INTERNAL_SERVER_ERROR);
	    }
	}

}
