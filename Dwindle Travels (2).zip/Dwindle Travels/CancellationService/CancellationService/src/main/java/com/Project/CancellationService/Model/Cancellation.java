package com.Project.CancellationService.Model;

import jakarta.persistence.Column;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import jakarta.persistence.Entity;

@Entity
@Table(name = "Cancellationsinfo")
public class Cancellation {
	@Id
	@Column(name = "ticketid")
	private int ticketid;
	@Column(name = "nooftickets")
	private int nooftickets;
	public int getTicketid() {
		return ticketid;
	}
	public void setTicketid(int ticketid) {
		this.ticketid = ticketid;
	}
	public int getNooftickets() {
		return nooftickets;
	}
	public void setNooftickets(int nooftickets) {
		this.nooftickets = nooftickets;
	}
	public Cancellation(int ticketid, int nooftickets) {
		super();
		this.ticketid = ticketid;
		this.nooftickets = nooftickets;
	}
	public Cancellation() {
		super();
	}
	

	

}
