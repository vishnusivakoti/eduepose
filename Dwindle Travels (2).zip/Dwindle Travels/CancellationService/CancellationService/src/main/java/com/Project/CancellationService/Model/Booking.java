package com.Project.CancellationService.Model;

import java.time.LocalDate;
import java.time.LocalDateTime;

import jakarta.persistence.Column;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;

@Table(name = "Bookinginfo")
public class Booking {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private int custId;
	@Column(name = "name")
	private String Name;
	@Column(name = "age")
	private int age;
	@Column(name = "gender")
	private String gender;
	@Column(name = "no_of_tickets")
	private int noOfTickets;
	@Column(name = "traveldate")
	private LocalDate traveldate;
	@Column(name = "source")
	private String source;
	@Column(name = "destination")
	private String destination;
	@Column(name = "starttime")
	private LocalDateTime starttime;
	@Column(name = "endtime")
	private LocalDateTime endtime;
	@Column(name = "TrainID")
	private int trainID;
	public int getTrainID() {
		return trainID;
	}
	public void setTrainID(int trainID) {
		this.trainID = trainID;
	}
	public LocalDateTime getStarttime() {
		return starttime;
	}
	public void setStarttime(LocalDateTime starttime) {
		this.starttime = starttime;
	}
	public LocalDateTime getEndtime() {
		return endtime;
	}
	public void setEndtime(LocalDateTime endtime) {
		this.endtime = endtime;
	}
	public String getSource() {
		return source;
	}
	public void setSource(String source) {
		this.source = source;
	}
	public String getDestination() {
		return destination;
	}
	public void setDestination(String destination) {
		this.destination = destination;
	}
	public int getCustId() {
		return custId;
	}
	public void setCustId(int custId) {
		this.custId = custId;
	}
	public String getName() {
		return Name;
	}
	public void setName(String name) {
		Name = name;
	}
	public int getAge() {
		return age;
	}
	public void setAge(int age) {
		this.age = age;
	}
	public String getGender() {
		return gender;
	}
	public void setGender(String gender) {
		this.gender = gender;
	}
	public int getNoOfTickets() {
		return noOfTickets;
	}
	public void setNoOfTickets(int noOfTickets) {
		this.noOfTickets = noOfTickets;
	}
	public LocalDate getTraveldate() {
		return traveldate;
	}
	public void setTraveldate(LocalDate traveldate) {
		this.traveldate = traveldate;
	}
	public Booking(int custId, String name, int age, String gender, int noOfTickets, LocalDate traveldate) {
		super();
		this.custId = custId;
		Name = name;
		this.age = age;
		this.gender = gender;
		this.noOfTickets = noOfTickets;
		this.traveldate = traveldate;
	}
	public Booking() {
		super();
	}
	
}
