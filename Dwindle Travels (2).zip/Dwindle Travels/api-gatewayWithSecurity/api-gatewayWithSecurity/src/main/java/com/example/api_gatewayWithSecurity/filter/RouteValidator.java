package com.example.api_gatewayWithSecurity.filter;

import java.util.List;
import java.util.function.Predicate;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.server.reactive.ServerHttpRequest;
import org.springframework.stereotype.Component;
import com.example.api_gatewayWithSecurity.service.JwtService;

@Component
public class RouteValidator {
	@Autowired
	JwtService jwtservice;

	public static final List<String> openApiEndpoints=
			List.of(
					"/security/register/user",
					"/security/authenticate",
					"/train/user/.*",
					"/eureka"
					);
	public static final List<String> AdminApiEndpoints=
			List.of(
					"/train/.*",
					"/booking/.*",
					"/cancellation/.*",
					"/eureka"
					);
	public static final List<String> UserApiEndpoints=
			List.of(
					"/booking/.*",
					"/cancellation/.*",
					"/eureka"
					);
	public static final List<String> HrApiEndpoints=
			List.of(
					"/security/HR/.*",
					"/booking/.*",
					"/cancellation/.*",
					"/eureka"
					);
	
	
	public Predicate<ServerHttpRequest> isSecured=
			request -> openApiEndpoints.stream()
			.noneMatch(uri->request.getURI().getPath().matches(uri));
			
			

	public Predicate<ServerHttpRequest> isAdminUri=
					(request) -> AdminApiEndpoints.stream()
					.anyMatch(uri->request.getURI().getPath().matches(uri));
	public Predicate<ServerHttpRequest> isUserUri=
							request -> UserApiEndpoints.stream()
							.anyMatch(uri->request.getURI().getPath().matches(uri));
	public Predicate<ServerHttpRequest> isHrUri=
									request -> HrApiEndpoints.stream()
									.anyMatch(uri->request.getURI().getPath().matches(uri));
	public boolean ValidateUsers(String token, ServerHttpRequest request) {
		String role=jwtservice.extractRole(token);
		if(isAdminUri.test(request) && role.equals("ROLE_ADMIN")) {
			return true;
		}
		if(isUserUri.test(request) && role.equals("ROLE_USER")) {
			return true;
		}
		if(isHrUri.test(request) && role.equals("ROLE_HR")) {
			return true;
		}
		return false;
	}
							
	
			
}
