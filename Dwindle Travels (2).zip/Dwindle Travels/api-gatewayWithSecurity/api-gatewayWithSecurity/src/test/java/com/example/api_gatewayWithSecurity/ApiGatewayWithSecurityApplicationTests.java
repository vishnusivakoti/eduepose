package com.example.api_gatewayWithSecurity;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ApiGatewayWithSecurityApplicationTests {

	@Test
	void contextLoads() {
	}

}
