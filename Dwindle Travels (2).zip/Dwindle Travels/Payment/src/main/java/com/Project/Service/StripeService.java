package com.Project.Service;

import com.Project.dto.BookingRequest;
import com.Project.dto.StripeResponse;
import com.stripe.Stripe;
import com.stripe.exception.StripeException;
import com.stripe.model.checkout.Session;
import com.stripe.param.checkout.SessionCreateParams;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

@Service
public class StripeService {

    @Value("${stripe.secretKey}")
    private String secretKey;

    public StripeResponse checkoutProducts(BookingRequest bookingRequest) {
        Stripe.apiKey = secretKey;

        SessionCreateParams.LineItem.PriceData.ProductData productData =
                SessionCreateParams.LineItem.PriceData.ProductData.builder()
                        .setName(bookingRequest.getName())
                        .build();

        SessionCreateParams.LineItem.PriceData priceData =
                SessionCreateParams.LineItem.PriceData.builder()
                        .setCurrency(bookingRequest.getCurrency() != null ? bookingRequest.getCurrency() : "USD")
                        .setUnitAmount(bookingRequest.getAmount())
                        .setProductData(productData)
                        .build();

        SessionCreateParams.LineItem lineItem =
                SessionCreateParams.LineItem.builder()
                        .setQuantity(bookingRequest.getNoOfTickets())
                        .setPriceData(priceData)
                        .build();

        SessionCreateParams params =
                SessionCreateParams.builder()
                        .setMode(SessionCreateParams.Mode.PAYMENT)
                        .setSuccessUrl("http://localhost:9090/success")
                        .setCancelUrl("http://localhost:9090/cancel")
                        .addLineItem(lineItem)
                        .build();

        try {
            Session session = Session.create(params);
            return new StripeResponse.Builder()
            		.setMessage("Sucess : Complete the Payment")
            		.setStatus(secretKey)
                    .setSessionId(session.getId())
                    .setSessionUrl(session.getUrl())
                    .build();
        } catch (StripeException e) {
            // You can log the error here
            return new StripeResponse.Builder()
                    .setStatus("Failure")
                    .setMessage("Payment failed: " + e.getMessage())
                    .build();
        }
    }

	public String getMesage() {
		return "Hello";
	}
}
