package com.Project.Controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.bind.annotation.GetMapping;

import com.Project.Service.StripeService;
import com.Project.dto.BookingRequest;
import com.Project.dto.StripeResponse;
@RestController
@RequestMapping("/payment")
public class checkOutController {

	@Autowired
    StripeService stripeService;

    public checkOutController(StripeService stripeService) {
        this.stripeService = stripeService;
    }

    @PostMapping("/checkout")
    public StripeResponse checkoutProducts(@RequestBody BookingRequest productRequest) {
    	StripeResponse reponse = stripeService.checkoutProducts(productRequest);
    	return reponse;

    }
    
    @GetMapping("/Hello")
    public String Hello() {
    	return "Hello";
    }

}
