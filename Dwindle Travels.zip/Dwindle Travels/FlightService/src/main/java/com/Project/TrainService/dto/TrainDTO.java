package com.Project.TrainService.dto;


import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.List;
import jakarta.validation.constraints.*;

public class TrainDTO {
    private Integer trainID;
    
    @NotBlank(message = "Source cannot be blank")
    @Size(min = 2, max = 50, message = "Source must be between 2 and 50 characters")
    private String source;
    
    @NotBlank(message = "Destination cannot be blank")
    @Size(min = 2, max = 50, message = "Destination must be between 2 and 50 characters")
    private String destination;
    
    @NotNull(message = "Travel date cannot be null")
    @Future(message = "Travel date must be in the future")
    private LocalDate travelDate;
    
    @NotNull(message = "Departure time cannot be null")
    private LocalDateTime departureTime;
    
    @DecimalMin(value = "0.5", message = "Travel hours must be at least 0.5")
    @DecimalMax(value = "48.0", message = "Travel hours cannot exceed 48")
    private double travelHours;
    
    @NotNull(message = "Arrival time cannot be null")
    private LocalDateTime arrivalTime;
    
    @Min(value = 1, message = "Price must be at least 1")
    @Max(value = 100000, message = "Price cannot exceed 100000")
    private int prices;
    
    @Min(value = 0, message = "Ticket availability cannot be negative")
    @Max(value = 1000, message = "Ticket availability cannot exceed 1000")
    private int ticketAvailability;
    
    @NotBlank(message = "Train name cannot be blank")
    @Size(min = 2, max = 100, message = "Train name must be between 2 and 100 characters")
    private String trainName;

    // Constructors
    public TrainDTO() {}

    public TrainDTO(Integer trainID, String source, String destination, LocalDate travelDate,
                    LocalDateTime departureTime, double travelHours, LocalDateTime arrivalTime,
                    int prices, int ticketAvailability, String trainName) {
        this.trainID = trainID;
        this.source = source;
        this.destination = destination;
        this.travelDate = travelDate;
        this.departureTime = departureTime;
        this.travelHours = travelHours;
        this.arrivalTime = arrivalTime;
        this.prices = prices;
        this.ticketAvailability = ticketAvailability;
        this.trainName = trainName;
    }

    // Getters and Setters
    public Integer getTrainID() { return trainID; }
    public void setTrainID(Integer trainID) { this.trainID = trainID; }
    
    public String getSource() { return source; }
    public void setSource(String source) { this.source = source; }
    
    public String getDestination() { return destination; }
    public void setDestination(String destination) { this.destination = destination; }
    
    public LocalDate getTravelDate() { return travelDate; }
    public void setTravelDate(LocalDate travelDate) { this.travelDate = travelDate; }
    
    public LocalDateTime getDepartureTime() { return departureTime; }
    public void setDepartureTime(LocalDateTime departureTime) { this.departureTime = departureTime; }
    
    public double getTravelHours() { return travelHours; }
    public void setTravelHours(double travelHours) { this.travelHours = travelHours; }
    
    public LocalDateTime getArrivalTime() { return arrivalTime; }
    public void setArrivalTime(LocalDateTime arrivalTime) { this.arrivalTime = arrivalTime; }
    
    public int getPrices() { return prices; }
    public void setPrices(int prices) { this.prices = prices; }
    
    public int getTicketAvailability() { return ticketAvailability; }
    public void setTicketAvailability(int ticketAvailability) { this.ticketAvailability = ticketAvailability; }
    
    public String getTrainName() { return trainName; }
    public void setTrainName(String trainName) { this.trainName = trainName; }
}
