package com.Project.TrainService.Controller;

import com.Project.TrainService.dto.RouteDTO;
import com.Project.TrainService.dto.TrainDTO;
import com.Project.TrainService.service.TrainService;
import jakarta.validation.Valid;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.time.LocalDate;
import java.util.List;

@RestController
@RequestMapping("/api/trains")
@CrossOrigin(origins = "*")
public class TrainController {

    @Autowired
    private TrainService trainService;

    @PostMapping
    public ResponseEntity<TrainDTO> createTrain(@Valid @RequestBody TrainDTO trainDTO) {
        TrainDTO createdTrain = trainService.createTrain(trainDTO);
        return new ResponseEntity<>(createdTrain, HttpStatus.CREATED);
    }

    @GetMapping("/{id}")
    public ResponseEntity<TrainDTO> getTrainById(@PathVariable Integer id) {
        TrainDTO train = trainService.getTrainById(id);
        return ResponseEntity.ok(train);
    }

    @GetMapping
    public ResponseEntity<List<TrainDTO>> getAllTrains() {
        List<TrainDTO> trains = trainService.getAllTrains();
        return ResponseEntity.ok(trains);
    }

    @PutMapping("/{id}")
    public ResponseEntity<TrainDTO> updateTrain(@PathVariable Integer id, @Valid @RequestBody TrainDTO trainDTO) {
        TrainDTO updatedTrain = trainService.updateTrain(id, trainDTO);
        return ResponseEntity.ok(updatedTrain);
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> deleteTrain(@PathVariable Integer id) {
        trainService.deleteTrain(id);
        return ResponseEntity.noContent().build();
    }

    @GetMapping("/search")
    public ResponseEntity<List<TrainDTO>> findTrainsByRoute(
            @RequestParam String source,
            @RequestParam String destination,
            @RequestParam @DateTimeFormat(iso = DateTimeFormat.ISO.DATE) LocalDate travelDate) {
        List<TrainDTO> trains = trainService.findTrainsByRoute(source, destination, travelDate);
        return ResponseEntity.ok(trains);
    }

    @GetMapping("/search/available")
    public ResponseEntity<List<TrainDTO>> findAvailableTrainsByRoute(
            @RequestParam String source,
            @RequestParam String destination,
            @RequestParam @DateTimeFormat(iso = DateTimeFormat.ISO.DATE) LocalDate travelDate) {
        List<TrainDTO> trains = trainService.findAvailableTrainsByRoute(source, destination, travelDate);
        return ResponseEntity.ok(trains);
    }

    // Special endpoint for finding routes with connections using BFS
    @GetMapping("/routes/connections")
    public ResponseEntity<List<RouteDTO>> findRoutesWithConnections(
            @RequestParam String source,
            @RequestParam String destination,
            @RequestParam @DateTimeFormat(iso = DateTimeFormat.ISO.DATE) LocalDate travelDate,
            @RequestParam(defaultValue = "2") int maxStops) {
        
        if (maxStops > 3) {
            maxStops = 3; // Limit to prevent excessive computation
        }
        
        List<RouteDTO> routes = trainService.findRoutesWithConnections(source, destination, travelDate, maxStops);
        return ResponseEntity.ok(routes);
    }

    @GetMapping("/source/{source}")
    public ResponseEntity<List<TrainDTO>> findTrainsBySource(@PathVariable String source) {
        List<TrainDTO> trains = trainService.findTrainsBySource(source);
        return ResponseEntity.ok(trains);
    }

    @GetMapping("/destination/{destination}")
    public ResponseEntity<List<TrainDTO>> findTrainsByDestination(@PathVariable String destination) {
        List<TrainDTO> trains = trainService.findTrainsByDestination(destination);
        return ResponseEntity.ok(trains);
    }

    @GetMapping("/date/{date}")
    public ResponseEntity<List<TrainDTO>> findTrainsByDate(
            @PathVariable @DateTimeFormat(iso = DateTimeFormat.ISO.DATE) LocalDate date) {
        List<TrainDTO> trains = trainService.findTrainsByDate(date);
        return ResponseEntity.ok(trains);
    }

    @PutMapping("/{id}/book")
    public ResponseEntity<String> bookTickets(@PathVariable Integer id, @RequestParam int tickets) {
        if (tickets <= 0) {
            return ResponseEntity.badRequest().body("Number of tickets must be positive");
        }
        
        boolean success = trainService.updateTicketAvailability(id, tickets);
        if (success) {
            return ResponseEntity.ok("Tickets booked successfully");
        } else {
            return ResponseEntity.badRequest().body("Insufficient tickets available");
        }
    }
}
