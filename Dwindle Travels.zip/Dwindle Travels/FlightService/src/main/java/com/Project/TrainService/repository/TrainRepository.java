package com.Project.TrainService.repository;


import com.Project.TrainService.entity.Train;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.time.LocalDate;
import java.util.List;
import java.util.Optional;

@Repository
public interface TrainRepository extends JpaRepository<Train, Integer> {
    
    List<Train> findBySourceAndDestinationAndTravelDate(String source, String destination, LocalDate travelDate);
    
    List<Train> findBySourceAndDestinationAndTravelDateAndTicketAvailabilityGreaterThan(
            String source, String destination, LocalDate travelDate, int ticketAvailability);
    
    List<Train> findBySource(String source);
    
    List<Train> findByDestination(String destination);
    
    List<Train> findByTravelDate(LocalDate travelDate);
    
    @Query("SELECT t FROM Train t WHERE t.source = :source AND t.travelDate = :travelDate AND t.ticketAvailability > 0")
    List<Train> findAvailableTrainsFromSource(@Param("source") String source, @Param("travelDate") LocalDate travelDate);
    
    @Query("SELECT DISTINCT t.source FROM Train t")
    List<String> findAllSources();
    
    @Query("SELECT DISTINCT t.destination FROM Train t")
    List<String> findAllDestinations();
    
    @Query("SELECT t FROM Train t WHERE t.source = :source AND t.destination = :destination AND t.travelDate >= :fromDate AND t.travelDate <= :toDate")
    List<Train> findTrainsBetweenDates(@Param("source") String source, 
                                       @Param("destination") String destination,
                                       @Param("fromDate") LocalDate fromDate,
                                       @Param("toDate") LocalDate toDate);
    
    Optional<Train> findByTrainName(String trainName);
    
    boolean existsByTrainName(String trainName);
}
