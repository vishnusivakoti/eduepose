package com.Project.TrainService.Exception;

public class TrainValidationException extends RuntimeException {
    public TrainValidationException(String message) {
        super(message);
    }
}
