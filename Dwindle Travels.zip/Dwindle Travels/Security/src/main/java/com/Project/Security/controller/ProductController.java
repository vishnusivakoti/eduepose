package com.Project.Security.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.web.bind.annotation.*;

import com.Project.Security.dto.AuthRequest;
import com.Project.Security.dto.UpdateAminDto;
import com.Project.Security.entity.UserInfo;
import com.Project.Security.service.JwtService;
import com.Project.Security.service.ProductService;

@RestController
@RequestMapping("/security")
public class ProductController {

    @Autowired
    private ProductService service;
    
    @Autowired
    private JwtService jwtService;

    @Autowired
    private AuthenticationManager authenticationManager;

    // Register new user
    @PostMapping("/register/user")
    public String addNewUser(@RequestBody UserInfo userInfo) {
    	if(userInfo.getRoles().equals("ROLE_USER")) {
    		return service.addUser(userInfo);
    	}
    	else {
    		return "Invalid Role";
    	}
    }
    // Authenticate and return JWT token with role
    @PostMapping("/authenticate")
    public String authenticateAndGetToken(@RequestBody AuthRequest authRequest) {
        Authentication authentication = authenticationManager.authenticate(
            new UsernamePasswordAuthenticationToken(authRequest.getUsername(), authRequest.getPassword())
        );

        if (authentication.isAuthenticated()) {
            // Fetch user details from database
            UserInfo user = service.getUserByUsername(authRequest.getUsername());

            // Generate JWT with role
            return jwtService.generateToken(authRequest.getUsername(), user.getRoles());
        } else {
            throw new UsernameNotFoundException("Invalid user request! Authentication failed.");
        }
    }
    @PostMapping("HR/add/admin")
    public ResponseEntity<String> addAdmin(@RequestHeader("Authorization") String authHeader, @RequestBody UserInfo userInfo) {
        String token = authHeader.replace("Bearer ", "");
        String role = jwtService.extractRole(token);

        if (!"ROLE_HR".equals(role)) {
            return ResponseEntity.status(HttpStatus.UNAUTHORIZED).body("Unauthorized access: Only HR can acess this URL.");
        }
        userInfo.setRoles("ROLE_ADMIN");
        return ResponseEntity.ok(service.addUser(userInfo));
    }
    
    @DeleteMapping("HR/delete/admin/hr")
    public ResponseEntity<String> deleteAdmin(@RequestHeader("Authorization") String authHeader,@RequestParam String username) {
        String token = authHeader.replace("Bearer ", "");
        String role = jwtService.extractRole(token);

        if (!"ROLE_HR".equals(role)) {
            return ResponseEntity.status(HttpStatus.UNAUTHORIZED).body("Unauthorized access: Only HR can acess this URL.");
        }
        return ResponseEntity.ok(service.DeleteAdmin(username));
    }
    @PutMapping("HR/update/admin/HR/{username}")
    public ResponseEntity<String> UpdateAdminHR(@RequestHeader("Authorization") String authHeader,@PathVariable String username ,@RequestBody UpdateAminDto dto) {
        String token = authHeader.replace("Bearer ", "");
        String role = jwtService.extractRole(token);

        if (!"ROLE_HR".equals(role)) {
            return ResponseEntity.status(HttpStatus.UNAUTHORIZED).body("Unauthorized access: Only HR can acess this URL.");
        }
        return ResponseEntity.ok(service.UpdateAdmin(username,dto));
    }
    @PostMapping("HR/add/hr")
    public ResponseEntity<String> addHr(@RequestHeader("Authorization") String authHeader, @RequestBody UserInfo userInfo) {
        String token = authHeader.replace("Bearer ", "");
        String role = jwtService.extractRole(token);

        if (!"ROLE_HR".equals(role)) {
            return ResponseEntity.status(HttpStatus.UNAUTHORIZED).body("Unauthorized access: Only HR can acess this URL.");
        }
        userInfo.setRoles("ROLE_HR");
        return ResponseEntity.ok(service.addUser(userInfo));
    }
    @GetMapping("/HR/getall")
    public ResponseEntity<?> getAllUsers(@RequestHeader("Authorization") String authHeader) {
        try {
            String token = authHeader.replace("Bearer ", "");
            String role = jwtService.extractRole(token);
            if (!"ROLE_HR".equals(role)) {
                return ResponseEntity
                        .status(HttpStatus.UNAUTHORIZED)
                        .body("Unauthorized access: Only HR can access this URL.");
            }
            List<UserInfo> users = service.getall();
            return ResponseEntity.ok(users);

        } catch (Exception e) {
            return ResponseEntity
                    .status(HttpStatus.INTERNAL_SERVER_ERROR)
                    .body("An error occurred while processing the request.");
        }
    }

}